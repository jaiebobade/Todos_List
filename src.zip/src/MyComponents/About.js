import React from 'react'

export const About = () => {
  return (
    <div>
        This is an about component
        <p> React is a JavaScript library developed by Facebook which, among other things,was used to build Instagram.com. 
           It aims to allow developers to create fast user interfaces for websites and applications alike easily.
           React Js is a front-end JavaScript library used in web development to build 
           interactive elements on website User Interfaces (UI) based on UI components.</p>
    </div>
  )
}
