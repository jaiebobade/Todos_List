
import React from 'react'
// import './footer.css'

export const Footer = () => {
  // let footerstyle = {
  //   position: "relative",
  //   top: "10vh",
  //   width: "100%",
    // border: "2px solid red"

  return (
    <footer className="bg-dark text-light"> 
    <p className="text-center">
      Copyright & copy; MyTodosList.com
      </p>
         
    </footer>
  )
}
